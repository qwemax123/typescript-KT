class Book {
  private static nextId = 1;
  public id: number;
  public data: Date;

  constructor(public title: string, public author: string) {
    this.id = Book.nextId++;
    this.data = new Date();
  }
}

class Store {
  private books: Book[] = [];

  add(book: Book): void {
    this.books.push(book);
  }

  getAll(): Book[] {
    return this.books;
  }

  Count(): number {
    return this.books.length;
  }

  check(title: string, author: string): boolean {
    return this.books.some(
      (b) => b.title === title && b.author === author
    );
  }
}

class App {
  private titleInput: HTMLInputElement;
  private authorInput: HTMLInputElement;
  private btn: HTMLButtonElement;
  private error: HTMLElement;
  private list: HTMLElement;
  private count: HTMLElement;

  private store = new Store();

  constructor() {
    this.titleInput = document.getElementById("titleInput") as HTMLInputElement;
    this.authorInput = document.getElementById("authorInput") as HTMLInputElement;
    this.btn = document.getElementById("addBtn") as HTMLButtonElement;
    this.error = document.getElementById("error")!;
    this.list = document.getElementById("list")!;
    this.count = document.getElementById("count")!;

    this.btn.addEventListener("click", () => this.addBook());
  }

  private normalize(str: string): string {
    return str.trim();
  }

  private showError(msg: string): void {
    this.error.textContent = msg;
  }

  private clearError(): void {
    this.error.textContent = "";
  }

  private addBook(): void {
    const rawTitle = this.titleInput.value;
    const rawAuthor = this.authorInput.value;

    const title = this.normalize(rawTitle);
    const author = this.normalize(rawAuthor);

    if (!title || !author) {
      this.showError("Заполните все поля");
      return;
    }

    if (this.store.check(title, author)) {
      this.showError("Такая книга уже есть в списке");
      return;
    }

    const book = new Book(title, author);
    this.store.add(book);

    this.titleInput.value = "";
    this.authorInput.value = "";

    this.clearError();
    this.render();
  }

  private render(): void {
    this.list.innerHTML = "";

    this.store.getAll().forEach((book) => {
      const div = document.createElement("div");
      div.className = "card";

      div.innerHTML = `
        ID: ${book.id}<br>
        Название: ${book.title}<br>
        Автор: ${book.author}<br>
        Дата создания: ${book.data.toLocaleString()}
      `;

      this.list.appendChild(div);
    });

    this.count.textContent = String(this.store.Count());
  }
}

new App();